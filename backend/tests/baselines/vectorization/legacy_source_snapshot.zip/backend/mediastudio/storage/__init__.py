"""User-selected media storage."""
