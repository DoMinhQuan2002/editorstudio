"""Image processing services."""
