from __future__ import annotations
from dataclasses import dataclass, field
import numpy as np


@dataclass
class Region:
    id: int
    mask: np.ndarray
    bbox: tuple[int, int, int, int]
    area: int
    kind: str = "flat"
    fill: str = "#000000"
    gradient: dict | None = None
    fit_error: float = 0
    paths: list[dict[str, str]] = field(default_factory=list)

    def metadata(self) -> dict:
        return dict(id=self.id, bbox=self.bbox, area=self.area, type=self.kind,
                    fill=self.fill, has_gradient=self.gradient is not None, fit_error=self.fit_error)
