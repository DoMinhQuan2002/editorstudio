"""Fit a fill only from samples inside its own region."""
from __future__ import annotations
import cv2
import numpy as np
from scipy.optimize import least_squares
from mediastudio.image_tools.vectorization.regions import Region


def hex_color(rgb) -> str:
    return "#{:02X}{:02X}{:02X}".format(*np.clip(np.round(rgb), 0, 255).astype(int))


def fit_fill(region: Region, rgb: np.ndarray) -> None:
    core=cv2.erode(region.mask.astype(np.uint8),np.ones((5,5),np.uint8))>0
    if np.count_nonzero(core)<8: core=region.mask
    y,x=np.where(core)
    stride=max(1,len(x)//4000); x=x[::stride].astype(float); y=y[::stride].astype(float)
    colors=rgb[y.astype(int),x.astype(int)].astype(float)
    region.fill=hex_color(np.median(colors,axis=0))
    flat_error=float(np.sqrt(np.mean((colors-np.median(colors,axis=0))**2)))
    region.fit_error=flat_error
    if flat_error<3 or len(x)<20:
        return
    xy=np.stack((x,y),axis=1)
    centered=colors-colors.mean(axis=0)
    _,_,vectors=np.linalg.svd(centered,full_matrices=False)
    score=centered@vectors[0]
    slope=np.linalg.lstsq(np.column_stack((xy,np.ones(len(x)))),score,rcond=None)[0][:2]
    norm=np.linalg.norm(slope)
    best=None
    def fit_stops(t):
        low,high=np.percentile(t,[1,99])
        if high-low<1e-6:return None
        positions=np.linspace(low,high,7)
        fitted=[]
        # Local medians reject compression outliers without palette reduction.
        for p in positions:
            selected=np.abs(t-p)<(high-low)/10
            if np.count_nonzero(selected)<3:
                selected=np.argsort(np.abs(t-p))[:min(12,len(t))]
            fitted.append(np.median(colors[selected],axis=0))
        fitted=np.asarray(fitted)
        prediction=np.column_stack([np.interp(t,positions,fitted[:,c]) for c in range(3)])
        error=float(np.sqrt(np.mean((prediction-colors)**2)))
        return positions,fitted,error
    if norm>1e-6:
        direction=slope/norm; t=xy@direction
        stops=fit_stops(t)
        if stops:
            positions,colors_fit,error=stops
            origin=xy.mean(axis=0); origin-=direction*(origin@direction)
            p1=origin+direction*positions[0];p2=origin+direction*positions[-1]
            best=dict(type="linear",x1=float(p1[0]),y1=float(p1[1]),x2=float(p2[0]),y2=float(p2[1]),
                      stops=[(float((p-positions[0])/(positions[-1]-positions[0])),hex_color(c)) for p,c in zip(positions,colors_fit)],error=error)
    if best is None or best["error"]>5:
        x0,y0,x1,y1=region.bbox; span=max(x1-x0,y1-y0,1)
        center=xy.mean(axis=0); local=(xy-center)/span
        # Fit radial center against RGB residual. Only keep it if materially
        # better than the linear fit; a radial label is not inferred from hue.
        def residual(c):
            radius=np.linalg.norm(local-c,axis=1)
            design=np.column_stack((radius,np.ones(len(radius))))
            coefficient=np.linalg.lstsq(design,colors,rcond=None)[0]
            return (design@coefficient-colors).ravel()/255
        solution=least_squares(residual,[0,0],bounds=(-3,3),max_nfev=25)
        c=center+solution.x*span
        radius=np.linalg.norm(xy-c,axis=1)
        stops=fit_stops(radius)
        if stops:
            positions,colors_fit,error=stops
            if best is None or error<best["error"]*.85:
                best=dict(type="radial",cx=float(c[0]),cy=float(c[1]),r=float(positions[-1]),
                          stops=[(float(p/positions[-1]),hex_color(color)) for p,color in zip(positions,colors_fit)],error=error)
    if best and best["error"]<=12 and best["error"]<flat_error*.8:
        region.kind="gradient";region.gradient=best;region.fit_error=best["error"]
    elif flat_error>8:
        region.kind="complex"
        region.fit_error=best["error"] if best else flat_error


def merge_boundary_regions(regions: list[Region], rgb: np.ndarray) -> list[Region]:
    """Absorb narrow compression bands; protect small, contrasting shapes."""
    canvas_area=rgb.shape[0]*rgb.shape[1]
    labels=np.zeros(rgb.shape[:2],np.int32)
    current={r.id:r for r in regions}
    for r in regions:labels[r.mask]=r.id
    for r in sorted(regions,key=lambda item:item.area):
        if r.area>canvas_area*.0015:continue
        core=cv2.erode(r.mask.astype(np.uint8),np.ones((3,3),np.uint8))>0
        ring=cv2.dilate(r.mask.astype(np.uint8),np.ones((3,3),np.uint8))>0
        neighbors=[current.get(int(i)) for i in np.unique(labels[ring & ~r.mask]) if i>0 and i!=r.id]
        neighbors=[n for n in neighbors if n is not None and n.area>r.area]
        if not neighbors:continue
        samples=core if np.any(core) else r.mask
        pixels=rgb[samples].astype(float)
        median=np.median(pixels,axis=0)
        costs=[]
        for n in neighbors:
            nearby=ring & n.mask
            color=np.median(rgb[nearby],axis=0)
            costs.append((float(np.sqrt(np.mean((median-color)**2))),n))
        cost,neighbor=min(costs,key=lambda item:item[0])
        # A coherent contrasting pupil/eye survives regardless of relative area.
        if cost>12 and np.count_nonzero(core)>=3:continue
        neighbor.mask |= r.mask;neighbor.area+=r.area
        yy,xx=np.where(neighbor.mask)
        neighbor.bbox=(int(xx.min()),int(yy.min()),int(xx.max()+1),int(yy.max()+1))
        labels[r.mask]=neighbor.id;current.pop(r.id,None)
    return list(current.values())
