from __future__ import annotations

import logging
import os
import shutil
import subprocess
import tempfile
import time
from pathlib import Path

import cv2
import numpy as np
import vtracer
from PIL import Image

from mediastudio.jobs.manager import Job
from mediastudio.storage.assets import Asset
from mediastudio.image_tools.vectorization.analysis import ImageAnalyzer
from mediastudio.image_tools.vectorization.composer import SvgComposer
from mediastudio.image_tools.vectorization.ocr import TextRecognizer, mask_text_regions


logger = logging.getLogger("mediastudio.vectorize")


class VectorizeError(RuntimeError):
    pass


class VectorizeService:
    """Creates editable SVG paths with VTracer or Potrace."""

    MAX_AUTO_COLORS = 24
    PALETTE_SAMPLE_LIMIT = 120_000
    ANALYSIS_SAMPLE_LIMIT = 24_000

    def __init__(self, models_directory: Path | None = None) -> None:
        self._backend_root = Path(__file__).resolve().parents[2]
        self._analyzer = ImageAnalyzer()
        self._text_recognizer = TextRecognizer(models_directory)
        self._svg_composer = SvgComposer()

    def run(
        self,
        job: Job,
        asset: Asset,
        *,
        engine: str,
        color_count: int | None,
        simplification: int | None,
        smooth_paths: bool,
        transparent_background: bool,
        output_directory: Path,
        mode: str = "auto",
    ) -> tuple[Path, int, int, int, int, str, dict[str, object]]:
        if engine not in {"auto", "vtracer", "potrace"}:
            raise VectorizeError("Công nghệ vector hóa chưa được hỗ trợ.")
        if mode not in {"auto", "fast", "quality", "ai"}:
            raise VectorizeError("Chế độ vector hóa chưa được hỗ trợ.")
        if color_count is not None and not 2 <= color_count <= self.MAX_AUTO_COLORS:
            raise VectorizeError(f"Số lượng màu phải nằm trong khoảng 2–{self.MAX_AUTO_COLORS}.")
        if simplification is not None and not 0 <= simplification <= 100:
            raise VectorizeError("Mức giản lược không hợp lệ.")

        started_at = time.perf_counter()
        output_directory.mkdir(parents=True, exist_ok=True)
        with Image.open(asset.path) as source:
            image = source.convert("RGBA")
        width, height = image.size
        original_image = image.copy()
        analysis = self._analyzer.analyze(image)
        selected_mode = analysis.recommended_pipeline if mode == "auto" else mode

        selected_engine = engine
        if selected_engine == "auto":
            selected_engine = (
                "potrace"
                if analysis.image_type == "line-art" and self._looks_like_monochrome_art(image) and self.potrace_path
                else "vtracer"
            )
        if selected_engine == "potrace" and self.potrace_path is None:
            raise VectorizeError(
                "Potrace chưa được cài. Chạy backend/setup.ps1 để cài engine này, hoặc chọn Ảnh màu — VTracer."
            )

        job.update(state="processing", progress=5, stage="Đang phân tích loại ảnh, màu và đường nét", is_indeterminate=False)
        if transparent_background:
            image = self._remove_border_background(image)
        artwork_image = image.copy()
        original_view_box = self._calculate_view_box(artwork_image)

        text_regions = []
        text_mask: np.ndarray | None = None
        should_recognize_text = selected_mode in {"quality", "ai"} and (analysis.has_text_candidate or mode in {"quality", "ai"})
        if should_recognize_text and transparent_background and analysis.background_type in {"flat", "transparent"}:
            job.update(
                progress=12,
                stage="Đang nhận diện chữ (lần đầu có thể cần tải mô hình OCR)",
                is_indeterminate=False,
            )
            detected_regions = self._text_recognizer.detect(image, progress=lambda stage: job.update(stage=stage))
            text_regions = [region for region in detected_regions if region.confidence >= 0.72]
            if text_regions:
                image, text_mask = mask_text_regions(image, text_regions, padding=max(2, round(min(width, height) * 0.004)))

        gradient_source = artwork_image
        scale = 1
        if selected_mode in {"quality", "ai"} and min(image.size) < 768 and max(image.size) < 1600:
            scale = 2
            trace_image = image.resize((image.width * scale, image.height * scale), Image.Resampling.BICUBIC)
            gradient_source = artwork_image.resize(
                (artwork_image.width * scale, artwork_image.height * scale), Image.Resampling.BICUBIC
            )
        else:
            trace_image = image

        if selected_mode in {"quality", "ai"} and analysis.image_type in {"logo", "icon", "illustration", "line-art"}:
            trace_image = self._edge_preserving_denoise(trace_image)

        debug_directory = self._debug_directory(output_directory, job.job_id)
        if debug_directory is not None:
            debug_directory.mkdir(parents=True, exist_ok=True)
            original_image.save(debug_directory / "01_original.png")
            artwork_image.save(debug_directory / "03_background_removed.png")
            if text_mask is not None:
                Image.fromarray(text_mask, mode="L").save(debug_directory / "04_text_mask.png")
            if scale > 1:
                trace_image.save(debug_directory / "02_upscaled.png")

        effective_color_count = color_count or self._estimate_color_count(trace_image)
        if color_count is None:
            if analysis.has_gradient:
                # The SVG composer restores a continuous fill gradient after
                # tracing, so a 24-color palette only creates extra noisy paths.
                effective_color_count = min(self.MAX_AUTO_COLORS, max(12, effective_color_count))
            elif analysis.image_type in {"logo", "icon", "illustration"}:
                effective_color_count = min(self.MAX_AUTO_COLORS, max(12, effective_color_count))
        if selected_mode == "fast" and color_count is None:
            effective_color_count = min(effective_color_count, 12)
        if debug_directory is not None:
            self._save_segmentation_preview(
                trace_image,
                debug_directory / "05_segmentation.png",
                color_count=effective_color_count,
            )
        effective_simplification = simplification if simplification is not None else self._estimate_simplification(trace_image)
        job.update(
            progress=20,
            stage=(
                f"Ảnh {analysis.image_type} · {effective_color_count} mức màu · "
                f"đang dựng nét{f' · giữ {len(text_regions)} vùng chữ' if text_regions else ''}"
            ),
            is_indeterminate=False,
        )

        output_path = output_directory / f"{job.job_id}_vector.svg"
        try:
            if selected_engine == "potrace":
                job.update(progress=25, stage="Đang tạo đường viền đơn sắc bằng Potrace", is_indeterminate=False)
                self._run_potrace(
                    trace_image,
                    output_path,
                    simplification=effective_simplification,
                    smooth_paths=smooth_paths,
                    job=job,
                    debug_directory=debug_directory,
                )
            else:
                job.update(progress=22, stage="Đang phân vùng màu bằng VTracer", is_indeterminate=False)
                self._run_vtracer(
                    trace_image,
                    output_path,
                    color_count=effective_color_count,
                    simplification=effective_simplification,
                    smooth_paths=smooth_paths,
                    job=job,
                    debug_directory=debug_directory,
                )

            job.update(progress=92, stage="Đang kiểm tra tệp SVG", is_indeterminate=False)
            if debug_directory is not None:
                shutil.copy2(output_path, debug_directory / "07_raw.svg")
            view_box = (
                original_view_box[0] * scale,
                original_view_box[1] * scale,
                original_view_box[2] * scale,
                original_view_box[3] * scale,
            )
            composition = self._svg_composer.compose(
                output_path,
                width=original_view_box[2],
                height=original_view_box[3],
                view_box=view_box,
                engine=selected_engine,
                image_type=analysis.image_type,
                source_image=gradient_source,
                text_regions=text_regions,
                reconstruct_gradients=analysis.has_gradient and selected_engine == "vtracer",
                coordinate_scale=scale,
            )
            path_count = composition.paths
            if path_count == 0:
                raise VectorizeError("Ảnh không có vùng đủ rõ để chuyển thành vector.")
            size = output_path.stat().st_size
            if size > 100 * 1024 * 1024:
                raise VectorizeError("SVG tạo ra quá lớn (trên 100 MB). Hãy giảm chi tiết hoặc dùng ảnh nhỏ hơn.")
            engine_name = "Potrace" if selected_engine == "potrace" else "VTracer"
            if debug_directory is not None:
                shutil.copy2(output_path, debug_directory / "08_composed.svg")
                shutil.copy2(output_path, debug_directory / "09_final.svg")
            metrics: dict[str, object] = {
                "imageType": analysis.image_type,
                "mode": mode,
                "pipeline": selected_mode,
                "textLayers": composition.text_layers,
                "gradients": composition.gradients,
                "processingTimeMs": round((time.perf_counter() - started_at) * 1000),
                "inputWidth": width,
                "inputHeight": height,
                "traceWidth": trace_image.width,
                "traceHeight": trace_image.height,
                "regions": analysis.estimated_regions,
            }
            return output_path, original_view_box[2], original_view_box[3], size, path_count, engine_name, metrics
        except VectorizeError:
            output_path.unlink(missing_ok=True)
            raise
        except (OSError, ValueError, RuntimeError, subprocess.SubprocessError) as error:
            output_path.unlink(missing_ok=True)
            logger.exception("Vectorization failed for job %s", job.job_id)
            raise VectorizeError("Không thể vector hóa ảnh. Hãy thử ảnh khác hoặc giảm mức chi tiết.") from error

    @property
    def potrace_path(self) -> Path | None:
        configured = os.environ.get("MEDIASTUDIO_POTRACE_PATH")
        if configured:
            executable = Path(configured)
            if executable.is_file():
                return executable
        on_path = shutil.which("potrace")
        if on_path:
            return Path(on_path)
        tools_directory = self._backend_root / "tools"
        if tools_directory.is_dir():
            return next(tools_directory.rglob("potrace.exe"), None)
        return None

    @staticmethod
    def _debug_directory(output_directory: Path, job_id: str) -> Path | None:
        enabled = os.environ.get("DEBUG_VECTOR", os.environ.get("MEDIASTUDIO_DEBUG_VECTOR", "")).strip().lower()
        if enabled not in {"1", "true", "yes", "on"}:
            return None
        return output_directory / "vector-debug" / job_id

    @staticmethod
    def _save_segmentation_preview(image: Image.Image, path: Path, *, color_count: int) -> None:
        rgba = np.asarray(image.convert("RGBA"))
        indexed = Image.fromarray(rgba[:, :, :3], mode="RGB").quantize(
            colors=color_count,
            method=Image.Quantize.MEDIANCUT,
            dither=Image.Dither.NONE,
        )
        labels = np.asarray(indexed, dtype=np.uint8)
        palette = cv2.applyColorMap(np.arange(256, dtype=np.uint8).reshape(1, 256), cv2.COLORMAP_TURBO)[0, :, ::-1]
        preview = np.empty_like(rgba)
        preview[:, :, :3] = palette[labels]
        preview[:, :, 3] = rgba[:, :, 3]
        Image.fromarray(preview, mode="RGBA").save(path)

    @staticmethod
    def _edge_preserving_denoise(image: Image.Image) -> Image.Image:
        rgba = np.asarray(image.convert("RGBA")).copy()
        filtered = cv2.bilateralFilter(rgba[:, :, :3], d=5, sigmaColor=18, sigmaSpace=2)
        visible = rgba[:, :, 3] > 16
        rgba[:, :, :3][visible] = filtered[visible]
        return Image.fromarray(rgba, mode="RGBA")

    @staticmethod
    def _run_vtracer(
        image: Image.Image,
        output_path: Path,
        *,
        color_count: int,
        simplification: int,
        smooth_paths: bool,
        job: Job,
        debug_directory: Path | None = None,
    ) -> None:
        output_path.parent.mkdir(parents=True, exist_ok=True)
        with tempfile.TemporaryDirectory(prefix="mediastudio-vector-") as temporary_directory:
            input_path = Path(temporary_directory) / "source.png"
            source_rgb = image.convert("RGB")
            alpha = image.getchannel("A")
            rgba = np.asarray(image.convert("RGBA"))
            visible_pixels = rgba[:, :, :3][rgba[:, :, 3] > 16]
            if visible_pixels.size == 0:
                raise VectorizeError("Không tìm thấy vùng ảnh còn nhìn thấy sau khi tách nền.")
            if len(visible_pixels) > VectorizeService.PALETTE_SAMPLE_LIMIT:
                indices = np.linspace(
                    0,
                    len(visible_pixels) - 1,
                    VectorizeService.PALETTE_SAMPLE_LIMIT,
                    dtype=np.int32,
                )
                visible_pixels = visible_pixels[indices]

            # Build the palette only from visible pixels. Transparent pixels may
            # contain arbitrary RGB values and must not consume palette entries.
            palette_source = Image.fromarray(visible_pixels.reshape(1, -1, 3).astype(np.uint8))
            palette = palette_source.quantize(
                colors=color_count,
                method=Image.Quantize.MEDIANCUT,
                dither=Image.Dither.NONE,
            )
            quantized = source_rgb.quantize(palette=palette, dither=Image.Dither.NONE).convert("RGB")
            quantized.putalpha(alpha)
            quantized.save(input_path, format="PNG")
            if debug_directory is not None:
                quantized.save(debug_directory / "06_quantized.png")
            job.update(progress=48, stage="Đang vẽ các lớp màu thành đường SVG", is_indeterminate=False)
            vtracer.convert_image_to_svg_py(
                str(input_path),
                str(output_path),
                colormode="color",
                hierarchical="cutout",
                mode="spline" if smooth_paths else "polygon",
                filter_speckle=max(4, min(18, round(min(image.size) * 0.016))),
                color_precision=8,
                layer_difference=12,
                corner_threshold=60,
                length_threshold=2.0 + simplification * 0.025,
                max_iterations=10,
                splice_threshold=45,
                path_precision=3,
            )

    @classmethod
    def _estimate_color_count(cls, image: Image.Image) -> int:
        sample = image.convert("RGBA")
        sample.thumbnail((768, 768), Image.Resampling.BILINEAR)
        rgba = np.asarray(sample)
        visible = rgba[:, :, 3] > 24
        pixels = rgba[:, :, :3][visible]
        if len(pixels) < 2:
            return 2
        if len(pixels) > cls.ANALYSIS_SAMPLE_LIMIT:
            indices = np.linspace(0, len(pixels) - 1, cls.ANALYSIS_SAMPLE_LIMIT, dtype=np.int32)
            pixels = pixels[indices]

        lab = cv2.cvtColor(pixels.reshape(-1, 1, 3), cv2.COLOR_RGB2LAB).reshape(-1, 3).astype(np.float32)
        unique_count = len(np.unique(lab, axis=0))
        clusters = min(cls.MAX_AUTO_COLORS, max(2, unique_count))
        criteria = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 35, 0.25)
        try:
            cv2.setRNGSeed(17)
            _, labels, centers = cv2.kmeans(lab, clusters, None, criteria, 1, cv2.KMEANS_PP_CENTERS)
        except cv2.error:
            return min(cls.MAX_AUTO_COLORS, max(4, len(np.unique(pixels, axis=0))))

        weights = np.bincount(labels.ravel(), minlength=clusters).astype(np.float64)
        parents = list(range(clusters))

        def find(index: int) -> int:
            while parents[index] != index:
                parents[index] = parents[parents[index]]
                index = parents[index]
            return index

        # Merge near-identical Lab centers so JPG edge noise does not count as
        # separate design colors. Keep small but visible details such as pupils.
        for first in range(clusters):
            for second in range(first):
                if float(np.linalg.norm(centers[first] - centers[second])) < 16.0:
                    parents[find(first)] = find(second)

        minimum_pixels = max(2, round(len(labels) * 0.0002))
        merged_weights: dict[int, float] = {}
        for index, weight in enumerate(weights):
            root = find(index)
            merged_weights[root] = merged_weights.get(root, 0.0) + weight
        significant_weights = np.asarray(
            [weight for weight in merged_weights.values() if weight >= minimum_pixels],
            dtype=np.float64,
        )
        if significant_weights.size == 0:
            return 2

        # Use the effective number of colors (cluster-distribution entropy)
        # instead of counting JPEG edge shades as separate design colors, then
        # reserve extra palette slots for real gradients and antialiased edges.
        probabilities = significant_weights / significant_weights.sum()
        effective_colors = int(np.ceil(float(np.exp(-np.sum(probabilities * np.log(probabilities)))) * 1.8))
        return min(cls.MAX_AUTO_COLORS, max(2, effective_colors))

    @staticmethod
    def _estimate_simplification(image: Image.Image) -> int:
        sample = image.convert("RGBA")
        sample.thumbnail((768, 768), Image.Resampling.BILINEAR)
        rgba = np.asarray(sample)
        visible = rgba[:, :, 3] > 24
        if not np.any(visible):
            return 4
        rgb = rgba[:, :, :3]
        gray = cv2.cvtColor(rgb, cv2.COLOR_RGB2GRAY)
        edges = cv2.Canny(gray, 60, 150) > 0
        edge_density = float(np.mean(edges[visible]))
        # At small source sizes, use the most conservative curve filtering.
        # A little more cleanup is safe on larger, noisy images while retaining detail.
        return 4 if min(sample.size) < 900 or edge_density > 0.12 else 7

    @staticmethod
    def _calculate_view_box(image: Image.Image) -> tuple[float, float, int, int]:
        """Trim transparent canvas while keeping comfortable margins around artwork."""
        width, height = image.size
        alpha = np.asarray(image.getchannel("A"))
        ys, xs = np.where(alpha > 16)
        if xs.size == 0:
            return 0.0, 0.0, width, height

        content_left = int(xs.min())
        content_top = int(ys.min())
        content_right = int(xs.max()) + 1
        content_bottom = int(ys.max()) + 1
        content_width = content_right - content_left
        content_height = content_bottom - content_top
        if content_width >= width * 0.98 and content_height >= height * 0.98:
            return 0.0, 0.0, width, height

        # Preserve the source aspect ratio. The art fills most of the view
        # horizontally while leaving room above and below for tall marks/text.
        aspect_ratio = width / height
        view_width = max(content_width / 0.90, content_height * aspect_ratio / 0.80)
        view_width = min(float(width), view_width)
        view_height = min(float(height), view_width / aspect_ratio)
        if view_width >= width - 1 and view_height >= height - 1:
            return 0.0, 0.0, width, height

        center_x = (content_left + content_right) / 2.0
        center_y = (content_top + content_bottom) / 2.0
        left = min(max(0.0, center_x - view_width / 2.0), width - view_width)
        top = min(max(0.0, center_y - view_height / 2.0), height - view_height)
        return left, top, max(1, round(view_width)), max(1, round(view_height))

    def _run_potrace(
        self,
        image: Image.Image,
        output_path: Path,
        *,
        simplification: int,
        smooth_paths: bool,
        job: Job,
        debug_directory: Path | None = None,
    ) -> None:
        executable = self.potrace_path
        if executable is None:
            raise VectorizeError("Không tìm thấy Potrace. Chạy backend/setup.ps1 để cài engine này.")

        with tempfile.TemporaryDirectory(prefix="mediastudio-potrace-") as temporary_directory:
            source_path = Path(temporary_directory) / "source.bmp"
            white_background = Image.new("RGBA", image.size, (255, 255, 255, 255))
            visible_image = Image.alpha_composite(white_background, image.convert("RGBA")).convert("RGB")
            gray = cv2.cvtColor(np.asarray(visible_image), cv2.COLOR_RGB2GRAY)
            _, binary = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY | cv2.THRESH_OTSU)
            border = np.concatenate((gray[0, :], gray[-1, :], gray[:, 0], gray[:, -1]))
            if float(np.mean(border)) < 127:
                binary = cv2.bitwise_not(binary)
            bitmap = np.where(binary > 0, 255, 0).astype(np.uint8)
            Image.fromarray(bitmap, mode="L").convert("1").save(source_path, format="BMP")
            if debug_directory is not None:
                Image.fromarray(bitmap, mode="L").save(debug_directory / "06_quantized.png")

            # Larger tolerance makes the curve fitter discard more small turns.
            opt_tolerance = 0.05 + (simplification / 100.0) * 0.55
            alpha_max = 1.0 if smooth_paths else 0.0
            command = [
                str(executable),
                "--svg",
                "--output",
                str(output_path),
                "--opttolerance",
                f"{opt_tolerance:.2f}",
                "--alphamax",
                f"{alpha_max:.1f}",
                "--turdsize",
                str(1 + simplification // 20),
                str(source_path),
            ]
            job.update(progress=55, stage="Đang dựng đường cong Bézier bằng Potrace", is_indeterminate=False)
            try:
                result = subprocess.run(command, capture_output=True, text=True, timeout=180, check=False)
            except subprocess.TimeoutExpired as error:
                raise VectorizeError("Potrace vượt quá thời gian xử lý 3 phút.") from error
            if result.returncode != 0:
                logger.warning("Potrace exited with %s: %s", result.returncode, result.stderr[-1000:])
                raise VectorizeError("Potrace không thể xử lý ảnh này.")

    @staticmethod
    def _looks_like_monochrome_art(image: Image.Image) -> bool:
        white_background = Image.new("RGBA", image.size, (255, 255, 255, 255))
        sample = Image.alpha_composite(white_background, image.convert("RGBA")).convert("RGB")
        sample.thumbnail((192, 192), Image.Resampling.BILINEAR)
        pixels = np.asarray(sample, dtype=np.int16)
        saturation = pixels.max(axis=2) - pixels.min(axis=2)
        if float(np.mean(saturation)) > 7.0:
            return False
        gray = cv2.cvtColor(pixels.astype(np.uint8), cv2.COLOR_RGB2GRAY)
        histogram = np.bincount(gray.ravel(), minlength=256).astype(np.float64)
        probabilities = histogram[histogram > 0] / gray.size
        entropy = float(-np.sum(probabilities * np.log2(probabilities)))
        return entropy <= 3.2

    @staticmethod
    def _remove_border_background(image: Image.Image) -> Image.Image:
        rgba = np.asarray(image.convert("RGBA")).copy()
        rgb = rgba[:, :, :3]
        border_pixels = np.concatenate((rgb[0], rgb[-1], rgb[:, 0], rgb[:, -1]), axis=0)
        background_rgb = np.median(border_pixels, axis=0).astype(np.uint8)
        border_lab = cv2.cvtColor(border_pixels.reshape(-1, 1, 3), cv2.COLOR_RGB2LAB).reshape(-1, 3).astype(np.float32)
        background_lab = np.median(border_lab, axis=0)
        border_distance = np.linalg.norm(border_lab - background_lab, axis=1)
        if float(np.mean(border_distance <= 18.0)) < 0.72:
            # A busy/photo-like edge does not provide enough evidence for a
            # safe automatic background removal, so retain the image as-is.
            return Image.fromarray(rgba, mode="RGBA")

        if int(background_rgb.min()) >= 220 and int(background_rgb.max() - background_rgb.min()) <= 32:
            # For white paper/JPEG backgrounds, include the light antialiasing
            # pixels connected to the canvas edge in the removable region.
            candidate = (rgb.min(axis=2) >= 232) & ((rgb.max(axis=2) - rgb.min(axis=2)) <= 28)
        else:
            image_lab = cv2.cvtColor(rgb, cv2.COLOR_RGB2LAB).astype(np.float32)
            distance = np.linalg.norm(image_lab - background_lab[None, None, :], axis=2)
            candidate = distance <= 18.0

        count, labels, _, _ = cv2.connectedComponentsWithStats(candidate.astype(np.uint8), connectivity=8)
        border_labels = np.unique(np.concatenate((labels[0], labels[-1], labels[:, 0], labels[:, -1])))
        border_labels = border_labels[(border_labels > 0) & (border_labels < count)]
        if border_labels.size:
            remove_mask = np.isin(labels, border_labels)
            rgba[:, :, 3][remove_mask] = 0
        return Image.fromarray(rgba, mode="RGBA")
