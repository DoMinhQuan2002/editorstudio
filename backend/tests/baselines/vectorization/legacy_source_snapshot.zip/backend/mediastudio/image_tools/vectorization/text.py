from __future__ import annotations
from dataclasses import replace
import os
from pathlib import Path
import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont
from mediastudio.image_tools.vectorization.ocr import TextRegion


def glyph_mask(image: Image.Image, region: TextRegion) -> np.ndarray:
    a=np.asarray(image.convert("RGBA"));mask=np.zeros(a.shape[:2],np.uint8)
    x,y=max(0,region.x),max(0,region.y)
    right,bottom=min(image.width,region.x+region.width),min(image.height,region.y+region.height)
    crop=a[y:bottom,x:right]
    if crop.size==0:return mask
    color=np.array([int(region.fill[i:i+2],16) for i in (1,3,5)],float)
    # Keep foreground coverage, excluding white counters inside A/O/etc.
    distance=np.linalg.norm(crop[:,:,:3].astype(float)-color,axis=2)
    limit=max(35,float(np.linalg.norm(255-color))*.55)
    mask[y:bottom,x:right]=((crop[:,:,3]>100)&(distance<limit)).astype(np.uint8)*255
    return mask


def detect_text_boxes(image: Image.Image) -> list[TextRegion]:
    """Lightweight independent detector used when the OCR reader fails."""
    a=np.asarray(image.convert("RGBA"));gray=cv2.cvtColor(a[:,:,:3],cv2.COLOR_RGB2GRAY)
    foreground=(a[:,:,3]>128)&(gray<180)
    count,labels,stats,_=cv2.connectedComponentsWithStats(foreground.astype(np.uint8),8)
    candidates=[]
    for x,y,w,h,area in stats[1:]:
        if 3<=h<=image.height*.2 and 2<=w<=image.width*.2 and area>=4:
            candidates.append((int(x),int(y),int(w),int(h)))
    rows=[]
    for box in sorted(candidates,key=lambda b:b[1]+b[3]/2):
        row=next((r for r in rows if abs(box[1]+box[3]/2-np.mean([b[1]+b[3]/2 for b in r]))<max(3,box[3]*.4)),None)
        if row is None:rows.append([box])
        else:row.append(box)
    result=[]
    for row in rows:
        if len(row)<3:continue
        x=min(b[0] for b in row);y=min(b[1] for b in row)
        right=max(b[0]+b[2] for b in row);bottom=max(b[1]+b[3] for b in row)
        if right-x<image.width*.12:continue
        pixels=a[y:bottom,x:right,:3][foreground[y:bottom,x:right]]
        color=np.median(pixels,axis=0).astype(int)
        result.append(TextRegion("",x,y,right-x,bottom-y,0,"#{:02X}{:02X}{:02X}".format(*color),400))
    return result


def match_style(image: Image.Image, region: TextRegion) -> TextRegion:
    mask=glyph_mask(image,region);yy,xx=np.where(mask>0)
    if not len(xx):return region
    x,y,right,bottom=int(xx.min()),int(yy.min()),int(xx.max()+1),int(yy.max()+1)
    reference=(mask[y:bottom,x:right]>0).astype(np.uint8)
    core=cv2.erode(reference,np.ones((3,3),np.uint8))>0
    pixels=np.asarray(image.convert("RGB"))[y:bottom,x:right][core if core.any() else reference>0]
    color=np.median(pixels,axis=0).astype(int)
    best=None
    directory=Path(os.environ.get("WINDIR","C:/Windows"))/"Fonts"
    # Match only locally available fonts; no network or font substitution hidden
    # in the exported file. Font name and approximation are recorded in metadata.
    for filename,weight in [("arial.ttf",400),("arialbd.ttf",700),("ariblk.ttf",900),
                            ("GOTHIC.TTF",400),("GOTHICB.TTF",700),("calibri.ttf",400),
                            ("calibrib.ttf",700),("segoeui.ttf",400),("segoeuib.ttf",700)]:
        path=directory/filename
        if not path.is_file():continue
        font=ImageFont.truetype(str(path),200)
        bbox=font.getbbox(region.text,anchor="ls")
        width,height=bbox[2]-bbox[0],bbox[3]-bbox[1]
        if width<=0 or height<=0:continue
        rendered=Image.new("L",(width,height))
        ImageDraw.Draw(rendered).text((-bbox[0],-bbox[1]),region.text,font=font,fill=255,anchor="ls")
        resized=np.asarray(rendered.resize((right-x,bottom-y),Image.Resampling.LANCZOS))>128
        similarity=np.count_nonzero(resized & (reference>0))/max(1,np.count_nonzero(resized | (reference>0)))
        if best is None or similarity>best[0]:best=(similarity,font,path,weight,bbox)
    updated=replace(region,x=x,y=y,width=right-x,height=bottom-y,fill="#{:02X}{:02X}{:02X}".format(*color))
    if best:
        _,font,path,weight,bbox=best
        sx=(right-x)/(bbox[2]-bbox[0]);sy=(bottom-y)/(bbox[3]-bbox[1])
        updated=replace(updated,font_family=font.getname()[0],font_weight=weight,font_size=200,font_file=str(path),
                        transform=(sx,sy,x-bbox[0]*sx,y-bbox[1]*sy))
    return updated
