from __future__ import annotations

import logging
from dataclasses import dataclass
from pathlib import Path
from statistics import median
from typing import Callable

import cv2
import numpy as np
from PIL import Image
from mediastudio.image_tools.vectorization.ocr_models import get_reader, inference_lock


logger = logging.getLogger("mediastudio.vectorize.ocr")


@dataclass(frozen=True, slots=True)
class TextRegion:
    text: str
    x: int
    y: int
    width: int
    height: int
    confidence: float
    fill: str
    font_weight: int
    font_family: str = "Arial"
    font_size: float = 0
    alignment: str = "left"
    font_file: str = ""
    transform: tuple[float, float, float, float] | None = None


class TextRecognizer:
    """Lazy EasyOCR adapter. Failure is non-fatal; the vector trace remains available."""

    def __init__(self, model_directory: Path | None = None) -> None:
        self.model_directory = model_directory
        self._reader: object | None = None
        self.available = False
        self.warnings: list[str] = []

    def detect(self, image: Image.Image, *, progress: Callable[[str], None] | None = None) -> list[TextRegion]:
        self.warnings = []
        try:
            reader = self._get_reader(progress)
            background = Image.new("RGBA", image.size, "white")
            rgb = np.asarray(Image.alpha_composite(background, image.convert("RGBA")).convert("RGB"))
            bgr = cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR)
            with inference_lock:
                results = reader.readtext(
                bgr,
                detail=1,
                paragraph=False,
                min_size=5,
                text_threshold=0.60,
                low_text=0.30,
                link_threshold=0.35,
                contrast_ths=0.08,
                adjust_contrast=0.55,
                decoder="greedy",
                )
            self.available = True
        except Exception as error:
            self.available = False
            self.warnings = [f"OCR chưa sẵn sàng; vùng chữ được xử lý đường nét riêng ({type(error).__name__})."]
            logger.exception("OCR_FALLBACK: independent text detection and isolated glyph tracing")
            return []

        boxes: list[tuple[int, int, int, int, str, float]] = []
        for result in results:
            if not isinstance(result, (tuple, list)) or len(result) < 3:
                continue
            points, value, confidence = result[0], str(result[1]).strip(), float(result[2])
            if not value or confidence < 0.48:
                continue
            point_array = np.asarray(points, dtype=np.float32).reshape(-1, 2)
            left = max(0, int(np.floor(point_array[:, 0].min())))
            top = max(0, int(np.floor(point_array[:, 1].min())))
            right = min(image.width, int(np.ceil(point_array[:, 0].max())))
            bottom = min(image.height, int(np.ceil(point_array[:, 1].max())))
            if right - left < 3 or bottom - top < 3:
                continue
            boxes.append((left, top, right - left, bottom - top, value, confidence))

        rows: list[list[tuple[int, int, int, int, str, float]]] = []
        for box in sorted(boxes, key=lambda item: item[1] + item[3] / 2):
            x, y, width, height, _, _ = box
            center_y = y + height / 2
            row = next(
                (
                    candidate
                    for candidate in rows
                    if abs(center_y - np.mean([item[1] + item[3] / 2 for item in candidate]))
                    <= max(5.0, min(height, median(item[3] for item in candidate)) * 0.45)
                ),
                None,
            )
            if row is None:
                rows.append([box])
            else:
                row.append(box)

        merged: list[tuple[int, int, int, int, str, float]] = []
        for row in rows:
            row.sort(key=lambda item: item[0])
            current = row[0]
            for following in row[1:]:
                x, y, width, height, text, confidence = current
                next_x, next_y, next_width, next_height, next_text, next_confidence = following
                gap = next_x - (x + width)
                if gap <= max(height, next_height) * 1.6:
                    left = min(x, next_x)
                    top = min(y, next_y)
                    right = max(x + width, next_x + next_width)
                    bottom = max(y + height, next_y + next_height)
                    current = (
                        left,
                        top,
                        right - left,
                        bottom - top,
                        f"{text} {next_text}".strip(),
                        min(confidence, next_confidence),
                    )
                else:
                    merged.append(current)
                    current = following
            merged.append(current)

        rgba = np.asarray(image.convert("RGBA"))
        regions: list[TextRegion] = []
        for x, y, width, height, text, confidence in merged:
            roi = rgba[y : y + height, x : x + width]
            # Erode the foreground to exclude JPEG/antialiasing edge colors.
            visible = cv2.erode((roi[:, :, 3] > 128).astype(np.uint8), np.ones((3, 3), np.uint8)) > 0
            if not np.any(visible):
                visible = roi[:, :, 3] > 128
            pixels = roi[:, :, :3][visible]
            if pixels.size == 0:
                continue
            fill_rgb = np.median(pixels, axis=0).round().astype(np.uint8)
            density = float(np.count_nonzero(visible)) / max(1, width * height)
            regions.append(
                TextRegion(
                    text=text,
                    x=x,
                    y=y,
                    width=width,
                    height=height,
                    confidence=confidence,
                    fill="#{:02X}{:02X}{:02X}".format(*map(int, fill_rgb)),
                    font_weight=900 if density >= 0.22 else 600,
                )
            )
        return regions

    def _get_reader(self, progress: Callable[[str], None] | None) -> object:
        if self._reader is not None:
            return self._reader
        if progress is not None:
            progress("Đang nạp OCR để nhận dạng chữ")
        self._reader = get_reader(self.model_directory)
        return self._reader


def mask_text_regions(image: Image.Image, regions: list[TextRegion], *, padding: int = 2) -> tuple[Image.Image, np.ndarray]:
    """Remove OCR-recognized glyphs from a flat/transparent logo before tracing."""
    rgba = np.asarray(image.convert("RGBA")).copy()
    mask = np.zeros(rgba.shape[:2], dtype=np.uint8)
    for region in regions:
        left = max(0, region.x - padding)
        top = max(0, region.y - padding)
        right = min(rgba.shape[1], region.x + region.width + padding)
        bottom = min(rgba.shape[0], region.y + region.height + padding)
        mask[top:bottom, left:right] = 255
    rgba[:, :, 3][mask > 0] = 0
    return Image.fromarray(rgba, mode="RGBA"), mask
