"""Error-bounded cubic fitting for traced region boundaries."""
from __future__ import annotations
import cv2
import numpy as np
from skimage.measure import find_contours
from shapely.geometry import LinearRing


def _unit(vector):
    length=np.linalg.norm(vector)
    return vector/max(length,1e-12)


def _fit(points, left, right, tolerance, depth=0):
    if len(points)<3:
        distance=np.linalg.norm(points[-1]-points[0])/3
        return [np.array([points[0],points[0]+left*distance,points[-1]+right*distance,points[-1]])]
    distances=np.r_[0,np.cumsum(np.linalg.norm(np.diff(points,axis=0),axis=1))]
    t=distances/max(distances[-1],1e-12);s=1-t
    b=np.stack((s**3,3*t*s*s,3*t*t*s,t**3),axis=1)
    a=np.stack((b[:,1,None]*left,b[:,2,None]*right),axis=1)
    residual=points-(b[:,0]+b[:,1])[:,None]*points[0]-(b[:,2]+b[:,3])[:,None]*points[-1]
    matrix=np.einsum('nik,njk->ij',a,a);rhs=np.einsum('nik,nk->i',a,residual)
    alpha=np.linalg.lstsq(matrix,rhs,rcond=1e-10)[0]
    if np.min(alpha)<1e-6 or np.max(alpha)>distances[-1]*2:
        alpha[:]=np.linalg.norm(points[-1]-points[0])/3
    curve=np.array([points[0],points[0]+alpha[0]*left,points[-1]+alpha[1]*right,points[-1]])
    error=np.sum((b@curve-points)**2,axis=1);split=int(np.argmax(error))
    if error[split]<=tolerance*tolerance or depth>=24:return [curve]
    split=max(1,min(len(points)-2,split));back=_unit(points[split-1]-points[split+1])
    return _fit(points[:split+1],left,back,tolerance,depth+1)+_fit(points[split:],-back,right,tolerance,depth+1)


def smooth_occupancy(occupancy: np.ndarray, scale: int, origin: tuple[float,float], tolerance: float=.65) -> str | None:
    paths=[]
    for contour in find_contours(occupancy,.5,fully_connected="high"):
        points=contour[:,::-1]/scale+np.asarray(origin)
        if len(points)<4:continue
        # Remove redundant samples, then preserve corners supported by edges of
        # at least two source pixels. Pixel staircases are not design corners.
        points=cv2.approxPolyDP(points.astype(np.float32),.12,True).reshape(-1,2).astype(float)
        if len(points)<3:continue
        corners=[]
        for i in range(len(points)):
            before=points[i]-points[i-1];after=points[(i+1)%len(points)]-points[i]
            if min(np.linalg.norm(before),np.linalg.norm(after))>=2 and np.dot(_unit(before),_unit(after))<.65:
                corners.append(i)
        if len(corners)<2:corners=[0,len(points)//2]
        corners.sort();curves=[]
        for j,start in enumerate(corners):
            end=corners[(j+1)%len(corners)]
            segment=points[start:end+1] if end>start else np.vstack((points[start:],points[:end+1]))
            curves.extend(_fit(segment,_unit(segment[1]-segment[0]),_unit(segment[-2]-segment[-1]),tolerance))
        sample=[]
        for c in curves:
            t=np.linspace(0,1,12);s=1-t
            sample.extend(np.stack((s**3,3*t*s*s,3*t*t*s,t**3),axis=1)@c)
        if len(sample)>=4 and not LinearRing(sample).is_simple:
            return None
        def pair(point):return f"{point[0]:.4f} {point[1]:.4f}"
        data="M "+pair(curves[0][0])
        for curve in curves:data+=" C "+" ".join(pair(point) for point in curve[1:])
        paths.append(data+" Z")
    return " ".join(paths) or None
