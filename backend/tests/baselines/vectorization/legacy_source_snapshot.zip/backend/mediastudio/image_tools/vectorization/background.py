from __future__ import annotations
import cv2
import numpy as np
from PIL import Image


def separate_background(image: Image.Image) -> tuple[Image.Image,str,list[str]]:
    rgba=np.asarray(image.convert("RGBA")).copy()
    if np.mean(rgba[:,:,3]<250)>.001:
        return Image.fromarray(rgba),"transparent",[]
    rgb=rgba[:,:,:3]
    border=np.concatenate((rgb[0],rgb[-1],rgb[:,0],rgb[:,-1]))
    lab=cv2.cvtColor(rgb,cv2.COLOR_RGB2LAB).astype(float)
    samples=np.concatenate((lab[0],lab[-1],lab[:,0],lab[:,-1]))
    center=np.median(samples,axis=0);distance=np.linalg.norm(samples-center,axis=1)
    if np.mean(distance<18)<.8:
        return image,"retained",["Nền phức tạp được giữ lại để tránh xóa nhầm chi tiết."]
    tolerance=float(np.clip(np.percentile(distance,90)+8,10,22))
    candidates=np.linalg.norm(lab-center,axis=2)<=tolerance
    background=np.median(border,axis=0)
    if background.min()>220 and np.ptp(background)<32:
        candidates |= (rgb.min(axis=2)>=232)&(np.ptp(rgb,axis=2)<=28)
    count,labels,_,_=cv2.connectedComponentsWithStats(candidates.astype(np.uint8),8)
    border_labels=np.unique(np.concatenate((labels[0],labels[-1],labels[:,0],labels[:,-1])))
    border_labels=border_labels[border_labels>0]
    rgba[:,:,3][np.isin(labels,border_labels)]=0
    return Image.fromarray(rgba),"removed",[]
