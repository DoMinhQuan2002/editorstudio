from __future__ import annotations
import re
import tempfile
from pathlib import Path
from xml.etree import ElementTree as ET
import cv2
import numpy as np
from PIL import Image
import vtracer
from mediastudio.image_tools.vectorization.regions import Region
from mediastudio.image_tools.vectorization.geometry import smooth_occupancy

SVG_NS="http://www.w3.org/2000/svg"
_TOKENS=re.compile(r"[A-Za-z]|[-+]?(?:\d*\.\d+|\d+\.?\d*)(?:[eE][-+]?\d+)?")


def normalized_path(data: str, scale: float, offset: tuple[float,float]) -> str:
    """Normalize VTracer's absolute M/L/C/Z output into source coordinates."""
    output=[];axis=0;command=""
    for token in _TOKENS.findall(data):
        if token.isalpha():
            if token not in {"M","L","C","Q","S","T","H","V","Z"}:
                raise ValueError(f"Unsupported tracer command: {token}")
            command=token;axis=0;output.append(token)
        else:
            index=0 if command=="H" else 1 if command=="V" else axis%2
            value=float(token)/scale+offset[index]
            output.append(f"{value:.4f}".rstrip("0").rstrip("."));axis+=1
    return " ".join(output)


def trace_region(region: Region, scale: int=3, debug_directory: Path | None=None) -> list[dict[str,str]]:
    x0,y0,x1,y1=region.bbox
    crop=region.mask[y0:y1,x0:x1].astype(np.float32)
    # A subpixel contour from the smooth occupancy field removes staircase
    # jitter while its 0.5 level keeps the original boundary within one pixel.
    crop=np.pad(crop,2)
    enlarged=cv2.resize(crop,None,fx=scale,fy=scale,interpolation=cv2.INTER_CUBIC)
    enlarged=cv2.GaussianBlur(enlarged,(0,0),max(.5,scale*.18))
    binary=np.where(enlarged>=.5,0,255).astype(np.uint8)
    with tempfile.TemporaryDirectory(prefix="media-region-") as temporary:
        source=Path(temporary)/"mask.png";output=Path(temporary)/"trace.svg"
        Image.fromarray(binary).save(source)
        vtracer.convert_image_to_svg_py(str(source),str(output),colormode="binary",mode="spline",
                                       filter_speckle=0,corner_threshold=60,length_threshold=1.2,
                                       max_iterations=10,splice_threshold=45,path_precision=4)
        root=ET.parse(output).getroot()
        if debug_directory is not None:
            debug_directory.mkdir(parents=True,exist_ok=True)
            (debug_directory/f"region-{region.id}.svg").write_bytes(output.read_bytes())
        paths=[]
        for path in root.findall(f".//{{{SVG_NS}}}path"):
            translate=re.search(r"translate\(\s*([-\d.]+)[ ,]+([-\d.]+)\s*\)",path.get("transform",""))
            tx,ty=map(float,translate.groups()) if translate else (0.,0.)
            data=normalized_path(path.get("d",""),scale,(x0-2+tx/scale,y0-2+ty/scale))
            paths.append({"d":data,"fill-rule":"evenodd"})
    fitted=smooth_occupancy(enlarged,scale,(x0-2,y0-2),tolerance=min(.7,max(.3,min(region.mask.shape)*.0012)))
    if fitted:
        paths=[{"d":fitted,"fill-rule":"evenodd"}]
    region.paths=paths
    return paths
