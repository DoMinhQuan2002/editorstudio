from __future__ import annotations

from dataclasses import asdict, dataclass

import cv2
import numpy as np
from PIL import Image


@dataclass(frozen=True, slots=True)
class ImageAnalysis:
    image_type: str
    has_text_candidate: bool
    has_gradient: bool
    background_type: str
    color_complexity: str
    estimated_colors: int
    estimated_regions: int
    edge_density: float
    recommended_pipeline: str

    def to_dict(self) -> dict[str, object]:
        return asdict(self)


class ImageAnalyzer:
    """Lightweight OpenCV analysis used to choose a vectorization strategy."""

    def analyze(self, image: Image.Image) -> ImageAnalysis:
        sample = image.convert("RGBA")
        sample.thumbnail((512, 512), Image.Resampling.BILINEAR)
        rgba = np.asarray(sample)
        height, width = rgba.shape[:2]
        alpha = rgba[:, :, 3]
        visible = alpha > 24
        background_type = self._background_type(rgba)
        estimated_colors = self._estimate_colors(rgba, visible)
        estimated_regions = self._estimate_regions(rgba, visible)
        color_complexity = "low" if estimated_colors <= 8 else "medium" if estimated_colors <= 16 else "high"
        has_text = self._has_text_candidate(rgba)
        has_gradient = self._has_gradient(rgba, visible)

        composite = self._composite_on_white(rgba)
        gray = cv2.cvtColor(composite, cv2.COLOR_RGB2GRAY)
        edges = cv2.Canny(gray, 60, 150) > 0
        edge_density = float(np.mean(edges[visible])) if np.any(visible) else 0.0
        saturation = composite.max(axis=2).astype(np.int16) - composite.min(axis=2).astype(np.int16)
        mean_saturation = float(np.mean(saturation[visible])) if np.any(visible) else 0.0

        if has_text and color_complexity != "high":
            image_type = "logo" if estimated_colors <= 16 else "text-heavy"
        elif background_type in {"flat", "transparent"} and estimated_colors <= 7 and edge_density > 0.025:
            image_type = "line-art" if mean_saturation < 12 else "icon"
        elif background_type == "complex" and (estimated_colors > 18 or edge_density > 0.16):
            image_type = "photo"
        else:
            image_type = "illustration"

        return ImageAnalysis(
            image_type=image_type,
            has_text_candidate=has_text,
            has_gradient=has_gradient,
            background_type=background_type,
            color_complexity=color_complexity,
            estimated_colors=estimated_colors,
            estimated_regions=estimated_regions,
            edge_density=edge_density,
            recommended_pipeline="fast" if image_type == "photo" else "quality",
        )

    @staticmethod
    def _composite_on_white(rgba: np.ndarray) -> np.ndarray:
        rgb = rgba[:, :, :3].astype(np.float32)
        alpha = rgba[:, :, 3:4].astype(np.float32) / 255.0
        return np.clip(rgb * alpha + 255.0 * (1.0 - alpha), 0, 255).astype(np.uint8)

    @staticmethod
    def _background_type(rgba: np.ndarray) -> str:
        alpha = rgba[:, :, 3]
        if np.mean(alpha < 250) > 0.005:
            return "transparent"

        rgb = rgba[:, :, :3]
        border = np.concatenate((rgb[0], rgb[-1], rgb[:, 0], rgb[:, -1]), axis=0)
        lab = cv2.cvtColor(border.reshape(-1, 1, 3), cv2.COLOR_RGB2LAB).reshape(-1, 3).astype(np.float32)
        center = np.median(lab, axis=0)
        distance = np.linalg.norm(lab - center, axis=1)
        return "flat" if float(np.mean(distance <= 16.0)) >= 0.72 else "complex"

    @staticmethod
    def _estimate_colors(rgba: np.ndarray, visible: np.ndarray) -> int:
        pixels = rgba[:, :, :3][visible]
        if len(pixels) < 2:
            return 2
        # Coarse RGB bins suppress JPEG edge noise before estimating entropy.
        bins = (pixels.astype(np.uint16) >> 5).astype(np.uint8)
        _, counts = np.unique(bins, axis=0, return_counts=True)
        counts = counts[counts >= max(2, round(len(pixels) * 0.0002))].astype(np.float64)
        if counts.size == 0:
            return 2
        probabilities = counts / counts.sum()
        effective = int(np.ceil(np.exp(-np.sum(probabilities * np.log(probabilities))) * 1.5))
        return min(24, max(2, effective))

    @staticmethod
    def _estimate_regions(rgba: np.ndarray, visible: np.ndarray) -> int:
        """Count substantial connected areas among the dominant coarse colors."""
        pixels = rgba[:, :, :3]
        bins = (pixels.astype(np.uint16) >> 5).astype(np.uint8)
        _, inverse, counts = np.unique(bins[visible], axis=0, return_inverse=True, return_counts=True)
        if counts.size == 0:
            return 0
        dominant = np.argsort(counts)[-min(16, len(counts)) :]
        area_threshold = max(3, round(visible.size * 0.00008))
        labels = np.full(visible.shape, -1, dtype=np.int16)
        labels[visible] = inverse.astype(np.int16)
        region_count = 0
        for label in dominant:
            mask = (labels == int(label)).astype(np.uint8)
            component_count, _, stats, _ = cv2.connectedComponentsWithStats(mask, connectivity=8)
            region_count += sum(int(area) >= area_threshold for area in stats[1:component_count, cv2.CC_STAT_AREA])
        return region_count

    @staticmethod
    def _has_gradient(rgba: np.ndarray, visible: np.ndarray) -> bool:
        if not np.any(visible):
            return False
        rgb = rgba[:, :, :3]
        blurred = cv2.GaussianBlur(rgb, (5, 5), 0).astype(np.float32)
        lab = cv2.cvtColor(blurred.astype(np.uint8), cv2.COLOR_RGB2LAB).astype(np.float32)
        horizontal = np.linalg.norm(lab[:, 1:] - lab[:, :-1], axis=2)
        vertical = np.linalg.norm(lab[1:] - lab[:-1], axis=2)
        saturation = rgb.max(axis=2).astype(np.int16) - rgb.min(axis=2).astype(np.int16)
        chromatic = visible & (saturation > 35)
        horizontal_visible = chromatic[:, 1:] & chromatic[:, :-1]
        vertical_visible = chromatic[1:] & chromatic[:-1]
        changes = np.concatenate((horizontal[horizontal_visible], vertical[vertical_visible]))
        if changes.size == 0:
            return False
        gradual_fraction = float(np.mean((changes > 0.6) & (changes < 9.0)))
        chromatic_lab = lab[chromatic]
        color_spread = float(np.linalg.norm(np.percentile(chromatic_lab, 90, axis=0) - np.percentile(chromatic_lab, 10, axis=0)))
        broad_variation = color_spread > 12.0
        return gradual_fraction > 0.12 and broad_variation

    @classmethod
    def _has_text_candidate(cls, rgba: np.ndarray) -> bool:
        composite = cls._composite_on_white(rgba)
        gray = cv2.cvtColor(composite, cv2.COLOR_RGB2GRAY)
        height, width = gray.shape
        minimum_size = max(3, round(min(width, height) * 0.008))
        maximum_height = max(minimum_size + 1, round(height * 0.18))

        for threshold_type in (cv2.THRESH_BINARY_INV, cv2.THRESH_BINARY):
            _, binary = cv2.threshold(gray, 0, 255, threshold_type | cv2.THRESH_OTSU)
            binary = cv2.morphologyEx(binary, cv2.MORPH_OPEN, np.ones((2, 2), dtype=np.uint8))
            count, _, stats, _ = cv2.connectedComponentsWithStats(binary, connectivity=8)
            components: list[tuple[int, int, int, int, int]] = []
            for x, y, box_width, box_height, area in stats[1:count]:
                if (
                    box_height >= minimum_size
                    and box_height <= maximum_height
                    and box_width >= max(2, round(width * 0.003))
                    and box_width <= width * 0.24
                    and area >= max(4, round(width * height * 0.000015))
                ):
                    components.append((int(x), int(y), int(box_width), int(box_height), int(area)))
            if len(components) < 4:
                continue

            # Text glyphs form a horizontal row with similar vertical centers.
            components.sort(key=lambda item: item[1] + item[3] / 2)
            rows: list[list[tuple[int, int, int, int, int]]] = []
            for component in components:
                center_y = component[1] + component[3] / 2
                row = next(
                    (
                        existing
                        for existing in rows
                        if abs(center_y - np.mean([item[1] + item[3] / 2 for item in existing]))
                        <= max(4, component[3] * 0.45)
                    ),
                    None,
                )
                if row is None:
                    rows.append([component])
                else:
                    row.append(component)

            for row in rows:
                if len(row) < 4:
                    continue
                left = min(item[0] for item in row)
                right = max(item[0] + item[2] for item in row)
                heights = np.asarray([item[3] for item in row], dtype=np.float32)
                if right - left >= width * 0.16 and float(np.std(heights) / max(1.0, np.mean(heights))) < 0.75:
                    return True
        return False
