"""Process cache and atomic, cross-process model preparation for EasyOCR."""
from __future__ import annotations

from contextlib import contextmanager
import hashlib
import logging
import os
from pathlib import Path
import tempfile
import threading
import time
import urllib.request
import zipfile

logger = logging.getLogger("mediastudio.vectorize.ocr")
_readers: dict[str, object] = {}
_initialize_lock = threading.RLock()
inference_lock = threading.RLock()


@contextmanager
def model_lock(directory: Path, timeout: float = 120):
    directory.mkdir(parents=True, exist_ok=True)
    with (directory / "models.lock").open("a+b") as handle:
        handle.seek(0, 2)
        if handle.tell() == 0:
            handle.write(b"0")
            handle.flush()
        deadline = time.monotonic() + timeout
        while True:
            try:
                handle.seek(0)
                if os.name == "nt":
                    import msvcrt
                    msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
                else:
                    import fcntl
                    fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
                break
            except OSError:
                if time.monotonic() >= deadline:
                    raise TimeoutError("Một tiến trình khác đang chuẩn bị OCR. Hãy thử lại sau.")
                time.sleep(0.1)
        try:
            yield
        finally:
            handle.seek(0)
            if os.name == "nt":
                import msvcrt
                msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                import fcntl
                fcntl.flock(handle, fcntl.LOCK_UN)


def _digest(path: Path) -> str:
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "md5").hexdigest()


def prepare_model(directory: Path, model: dict) -> Path:
    """Called under model_lock. Never writes EasyOCR's shared temp.zip."""
    destination = directory / model["filename"]
    if destination.is_file() and _digest(destination) == model["md5sum"]:
        return destination
    with tempfile.TemporaryDirectory(prefix="download-", dir=directory) as temporary:
        archive = Path(temporary) / "model.zip"
        started = time.monotonic()
        size = 0
        with urllib.request.urlopen(model["url"], timeout=15) as response, archive.open("wb") as output:
            while chunk := response.read(1024 * 1024):
                size += len(chunk)
                if time.monotonic() - started > 90 or size > 300 * 1024 * 1024:
                    raise TimeoutError("Tải mô hình OCR vượt giới hạn thời gian hoặc dung lượng.")
                output.write(chunk)
            output.flush()
            os.fsync(output.fileno())
        candidate = Path(temporary) / model["filename"]
        with zipfile.ZipFile(archive) as package:
            info = package.getinfo(model["filename"])
            if info.file_size > 500 * 1024 * 1024:
                raise ValueError("Mô hình OCR có dung lượng không hợp lệ.")
            with package.open(info) as source, candidate.open("wb") as output:
                while chunk := source.read(1024 * 1024):
                    output.write(chunk)
        if _digest(candidate) != model["md5sum"]:
            raise ValueError("Mô hình OCR tải về không khớp checksum.")
        # Retry transient Windows sharing violations without deleting a valid model.
        for attempt in range(20):
            try:
                os.replace(candidate, destination)
                break
            except PermissionError:
                if attempt == 19:
                    raise
                time.sleep(0.1)
    return destination


def get_reader(directory: Path | None = None):
    directory = directory or Path(os.environ.get("LOCALAPPDATA", str(Path.home()))) / "MediaStudio/models/realesrgan/easyocr"
    key = str(directory.resolve()).casefold()
    with _initialize_lock:
        if key in _readers:
            return _readers[key]
        logger.info("OCR_INITIALIZING model_directory=%s", directory)
        try:
            import easyocr
            from easyocr.config import detection_models, recognition_models
            with model_lock(directory):
                prepare_model(directory, detection_models["craft"])
                prepare_model(directory, recognition_models["gen2"]["latin_g2"])
                reader = easyocr.Reader(["en", "vi"], gpu=False,
                                        model_storage_directory=str(directory),
                                        download_enabled=False, verbose=False)
            _readers[key] = reader
            logger.info("OCR_READY model_directory=%s", directory)
            return reader
        except Exception:
            logger.exception("OCR_FAILED model_directory=%s", directory)
            raise
