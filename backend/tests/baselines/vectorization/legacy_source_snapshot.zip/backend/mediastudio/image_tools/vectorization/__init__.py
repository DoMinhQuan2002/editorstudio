"""Analysis and reconstruction helpers for raster-to-SVG conversion."""

