from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from xml.etree import ElementTree as ET

import numpy as np
import cv2
from PIL import Image

from mediastudio.image_tools.vectorization.ocr import TextRegion


SVG_NS = "http://www.w3.org/2000/svg"
ET.register_namespace("", SVG_NS)
_TRANSLATE = re.compile(r"translate\(\s*(-?[\d.]+)(?:[ ,]+(-?[\d.]+))?\s*\)")


@dataclass(frozen=True, slots=True)
class SvgComposition:
    paths: int
    text_layers: int
    gradients: int


class SvgComposer:
    """Normalize traced SVG and compose editable text and reconstructed fills."""

    def compose(
        self,
        path: Path,
        *,
        width: int,
        height: int,
        view_box: tuple[float, float, int, int],
        engine: str,
        image_type: str,
        source_image: Image.Image,
        text_regions: list[TextRegion],
        reconstruct_gradients: bool,
        coordinate_scale: int = 1,
    ) -> SvgComposition:
        source = ET.parse(path).getroot()
        left, top, view_width, view_height = view_box
        output_root = ET.Element(f"{{{SVG_NS}}}svg", {
            "width": f"{width}px",
            "height": f"{height}px",
            "viewBox": f"{left:.3f} {top:.3f} {view_width} {view_height}",
        })
        for name in ("version", "baseProfile"):
            if source.get(name):
                output_root.set(name, source.get(name, ""))

        defs = ET.SubElement(output_root, f"{{{SVG_NS}}}defs")
        stops = self._gradient_stops(source_image) if reconstruct_gradients else []
        graphic = ET.SubElement(output_root, f"{{{SVG_NS}}}g", {
            "id": "graphic",
            "data-engine": "Potrace" if engine == "potrace" else "VTracer",
            "data-image-type": image_type,
        })
        path_count = 0
        gradient_count = 0

        def copy_element(element: ET.Element, parent: ET.Element) -> None:
            nonlocal path_count, gradient_count
            element_type = element.tag.rsplit("}", 1)[-1]
            if element_type == "g":
                copied = ET.SubElement(parent, f"{{{SVG_NS}}}g")
                for name, value in element.attrib.items():
                    if name != "id":
                        copied.set(name, value)
            elif element_type == "path":
                path_data = (element.get("d") or "").strip()
                if not path_data:
                    return
                copied = ET.SubElement(parent, f"{{{SVG_NS}}}path")
                for name, value in element.attrib.items():
                    if name not in {"d", "id"}:
                        copied.set(name, value)
                copied.set("d", path_data)
                path_count += 1
                copied.set("id", f"vector-path-{path_count}")

                if stops and self._is_warm_color(element.get("fill", "")):
                    gradient_id = f"reconstructed-gradient-{gradient_count + 1}"
                    gradient = ET.SubElement(defs, f"{{{SVG_NS}}}linearGradient", {
                        "id": gradient_id,
                        "gradientUnits": "userSpaceOnUse",
                        "x1": str(stops[0][0]),
                        "y1": "0",
                        "x2": str(stops[-1][0]),
                        "y2": "0",
                    })
                    translation = _TRANSLATE.search(element.get("transform", ""))
                    if translation:
                        tx = float(translation.group(1))
                        ty = float(translation.group(2) or 0)
                        gradient.set("gradientTransform", f"translate({-tx:.3f},{-ty:.3f})")
                    for x_position, color in stops:
                        offset = (x_position - stops[0][0]) / max(1.0, stops[-1][0] - stops[0][0])
                        ET.SubElement(gradient, f"{{{SVG_NS}}}stop", {
                            "offset": f"{offset:.4f}",
                            "stop-color": color,
                        })
                    copied.set("data-traced-fill", element.get("fill", ""))
                    copied.set("fill", f"url(#{gradient_id})")
                    gradient_count += 1
            else:
                return

            for child in element:
                copy_element(child, copied)

        for element in source:
            if element.tag.rsplit("}", 1)[-1] in {"g", "path"}:
                copy_element(element, graphic)

        typography = ET.SubElement(output_root, f"{{{SVG_NS}}}g", {"id": "typography"})
        for index, region in enumerate(text_regions, start=1):
            text = ET.SubElement(typography, f"{{{SVG_NS}}}text", {
                "id": f"recognized-text-{index}",
                "x": f"{(region.x + region.width / 2) * coordinate_scale:.2f}",
                "y": f"{(region.y + region.height * 0.90) * coordinate_scale:.2f}",
                "text-anchor": "middle",
                "font-family": "Arial, Helvetica, sans-serif",
                "font-size": f"{max(1, region.height * 1.24 * coordinate_scale):.2f}",
                "font-weight": str(region.font_weight),
                "textLength": f"{region.width * coordinate_scale:.2f}",
                "lengthAdjust": "spacingAndGlyphs",
                "fill": region.fill,
                "data-confidence": f"{region.confidence:.3f}",
            })
            text.text = region.text

        if len(defs) == 0:
            output_root.remove(defs)
        if not text_regions:
            output_root.remove(typography)

        temporary_path = path.with_suffix(".composed.svg")
        ET.ElementTree(output_root).write(temporary_path, encoding="utf-8", xml_declaration=True)
        temporary_path.replace(path)
        return SvgComposition(paths=path_count, text_layers=len(text_regions), gradients=int(gradient_count > 0))

    @staticmethod
    def _is_warm_color(color: str) -> bool:
        if not color.startswith("#") or len(color) != 7:
            return False
        try:
            red, green, blue = (int(color[index : index + 2], 16) for index in (1, 3, 5))
        except ValueError:
            return False
        return red - green >= 18 and green - blue >= 18 and red - blue >= 48

    @staticmethod
    def _gradient_stops(image: Image.Image) -> list[tuple[float, str]]:
        rgba = np.asarray(image.convert("RGBA"))
        rgb = rgba[:, :, :3]
        hsv = cv2.cvtColor(rgb, cv2.COLOR_RGB2HSV)
        visible = rgba[:, :, 3] > 24
        hue = hsv[:, :, 0]
        saturation = hsv[:, :, 1]
        value = hsv[:, :, 2]
        warm = visible & (hue >= 5) & (hue <= 45) & (saturation > 25) & (value > 140)
        ys, xs = np.where(warm)
        if xs.size < 32:
            return []

        left, right = int(xs.min()), int(xs.max())
        if right - left < 12:
            return []
        # Preserve the spatial color progression. Sorting by hue and then
        # assigning those colors left-to-right can reverse or scramble a logo's
        # real gradient when several warm regions overlap in hue.
        x_bins = np.linspace(left, right + 1, 6, dtype=np.int32)
        stops: list[tuple[float, str]] = []
        for start, end in zip(x_bins[:-1], x_bins[1:]):
            if end <= start:
                continue
            region_mask = warm[:, start:end]
            region_pixels = rgb[:, start:end][region_mask]
            if region_pixels.shape[0] < 8:
                continue
            color = np.median(region_pixels, axis=0).round().astype(np.uint8)
            position = (start + end - 1) / 2.0
            stops.append((position, "#{:02X}{:02X}{:02X}".format(*map(int, color))))
        return stops if len(stops) >= 2 else []
