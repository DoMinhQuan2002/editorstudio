"""Separate continuous color regions using edges, then spatial watershed.

Palette entries are never used as region labels. A smooth color ramp stays a
single region unless a real edge separates it from a neighbouring component.
"""
from __future__ import annotations
import cv2
import numpy as np
from scipy import ndimage as ndi
from skimage.segmentation import watershed
from skimage.segmentation import felzenszwalb
from PIL import Image
from mediastudio.image_tools.vectorization.regions import Region


class Segmenter:
    def segment(self, image: Image.Image) -> list[Region]:
        return self._graph_regions(image)

    def _graph_regions(self, image: Image.Image) -> list[Region]:
        rgba = np.asarray(image.convert("RGBA"))
        rgb = cv2.bilateralFilter(rgba[:, :, :3], 5, 18, 2)
        visible = rgba[:, :, 3] > 128
        if not visible.any():
            return []
        h, w = visible.shape
        # Local graph segmentation respects discontinuities without imposing a
        # global palette. Smooth ramps are merged using their spatial color fit.
        labels = felzenszwalb(rgb, scale=80, sigma=0.65, min_size=5) + 1
        labels[~visible] = 0
        ids = np.unique(labels[visible]); parent = {int(i): int(i) for i in ids}
        y, x = np.mgrid[:h, :w]
        features = np.stack((x / w, y / h, np.ones((h,w))), axis=2)
        stats = {}
        for label in ids:
            mask = labels == label
            a = features[mask]; b = rgb[mask].astype(float)
            stats[int(label)] = (len(a), a.T @ a, a.T @ b, np.sum(b*b))
        edges = set()
        for a, b in ((labels[:-1],labels[1:]), (labels[:,:-1],labels[:,1:])):
            differing=(a!=b)&(a>0)&(b>0)
            edges.update(tuple(sorted(map(int,p))) for p in np.unique(np.stack((a[differing],b[differing]),axis=1),axis=0))
        def find(i):
            while parent[i] != i:
                parent[i] = parent[parent[i]]; i = parent[i]
            return i
        def error(s, coeff):
            n, xx, xy, yy = s
            return float(np.sqrt(max(0, yy-2*np.sum(coeff*xy)+np.sum(coeff*(xx@coeff))) / max(1,n*3)))
        # Bound each side's error so a small dark feature cannot disappear into
        # a much larger bright region just because its global error is small.
        for _ in range(8):
            candidates=[]
            for first,second in edges:
                a,b=find(first),find(second)
                if a==b: continue
                sa,sb=stats[a],stats[b]
                combined=tuple(sa[i]+sb[i] for i in range(4))
                coeff=np.linalg.lstsq(combined[1],combined[2],rcond=1e-8)[0]
                cost=max(error(sa,coeff),error(sb,coeff))
                if cost <= 4.5: candidates.append((cost,a,b))
            merged=0
            for _,first,second in sorted(candidates):
                a,b=find(first),find(second)
                if a==b:continue
                sa,sb=stats[a],stats[b]; combined=tuple(sa[i]+sb[i] for i in range(4))
                coeff=np.linalg.lstsq(combined[1],combined[2],rcond=1e-8)[0]
                if max(error(sa,coeff),error(sb,coeff)) > 4.5:continue
                parent[b]=a;stats[a]=combined;merged+=1
            if not merged:break
        lookup=np.zeros(int(labels.max())+1,np.int32)
        for i in ids:lookup[i]=find(int(i))
        labels=lookup[labels]
        # Quantization/JPEG boundaries form narrow slivers. Keep coherent cores
        # as markers, then give boundary pixels back by spatial watershed. This
        # removes slivers without deleting pixels from the graphic silhouette.
        markers=np.zeros_like(labels); marker_id=0
        for label in np.unique(labels[visible]):
            mask=labels==label
            yy,xx=np.where(mask); x0,x1=xx.min(),xx.max()+1; y0,y1=yy.min(),yy.max()+1
            patch=np.pad(mask[y0:y1,x0:x1],1)
            core=ndi.distance_transform_edt(patch)[1:-1,1:-1] >= 1.8
            if np.count_nonzero(core) >= 3:
                marker_id+=1
                markers[y0:y1,x0:x1][core]=marker_id
        objects, count=ndi.label(visible)
        for label in range(1,count+1):
            mask=objects==label
            if not np.any(markers[mask]) and np.count_nonzero(mask)>=6:
                marker_id+=1;markers[mask]=marker_id
        lab=cv2.cvtColor(rgb,cv2.COLOR_RGB2LAB).astype(np.float32)
        dx=cv2.Sobel(lab,cv2.CV_32F,1,0,ksize=3)/8
        dy=cv2.Sobel(lab,cv2.CV_32F,0,1,ksize=3)/8
        magnitude=np.sqrt(np.sum(dx*dx+dy*dy,axis=2))
        labels=watershed(magnitude,markers,mask=visible)
        regions=[]
        for i,label in enumerate(np.unique(labels[visible]),start=1):
            if label==0:continue
            mask=labels==label; yy,xx=np.where(mask)
            regions.append(Region(i,mask,(int(xx.min()),int(yy.min()),int(xx.max()+1),int(yy.max()+1)),len(xx)))
        return regions

    def _watershed_regions(self, image: Image.Image) -> list[Region]:
        rgba = np.asarray(image.convert("RGBA"))
        visible = rgba[:, :, 3] > 128
        rgb = rgba[:, :, :3].copy()
        # Extend foreground colors into transparency before filtering; arbitrary
        # RGB behind alpha must not introduce edges or black halos.
        if not np.any(visible):
            return []
        indices = ndi.distance_transform_edt(~visible, return_distances=False, return_indices=True)
        rgb[~visible] = rgb[tuple(indices[:, ~visible])]
        rgb = cv2.bilateralFilter(rgb, 5, 16, 2)
        lab = cv2.cvtColor(rgb, cv2.COLOR_RGB2LAB).astype(np.float32)
        # Sobel/8 expresses a local difference per input pixel in OpenCV Lab.
        dx = cv2.Sobel(lab, cv2.CV_32F, 1, 0, ksize=3) / 8
        dy = cv2.Sobel(lab, cv2.CV_32F, 0, 1, ksize=3) / 8
        magnitude = np.sqrt(np.sum(dx * dx + dy * dy, axis=2))
        # Three Lab units/pixel separates design edges from gradual shading;
        # the bilateral pass above suppresses smaller JPEG fluctuations.
        edge = magnitude > 3.0
        edge = cv2.dilate(edge.astype(np.uint8), np.ones((3, 3), np.uint8)) > 0
        interior = cv2.erode(visible.astype(np.uint8), np.ones((3, 3), np.uint8)) > 0
        cores = interior & ~edge
        components, count = ndi.label(cores)
        sizes = np.bincount(components.ravel())
        # A seed needs a few coherent samples, not a single JPEG outlier.
        seed_minimum = max(2, round(visible.size * 0.000006))
        retained = np.flatnonzero(sizes >= seed_minimum)
        retained = retained[retained != 0]
        markers = np.zeros(visible.shape, np.int32)
        for i, label in enumerate(retained, start=1):
            markers[components == label] = i
        # Keep small disconnected high-contrast features even when they have no
        # eroded core (e.g. a pupil). Their connected mask is the seed.
        objects, objects_count = ndi.label(visible)
        next_id = len(retained) + 1
        for label in range(1, objects_count + 1):
            mask = objects == label
            if not np.any(markers[mask]) and np.count_nonzero(mask) >= 3:
                markers[mask] = next_id
                next_id += 1
        if not np.any(markers):
            markers[visible] = 1
        labels = watershed(magnitude, markers, mask=visible, watershed_line=False)
        regions = []
        for label in np.unique(labels):
            if label == 0:
                continue
            mask = labels == label
            y, x = np.where(mask)
            regions.append(Region(int(label), mask, (int(x.min()), int(y.min()), int(x.max()+1), int(y.max()+1)), len(x)))
        return regions
